osx-nat-pf
==========

This script (osx-nat-pf.sh) could be used to enable routing and NAT for Admin network (10.20.0.0/24) in Mac OSX 9 (Yosemite) or Mac OSX 10 (El Capitan). The previous versions of Mac OSX use 'ipfw' so another solution should be used.

This script could be used for debugging purposes and uses an administrative permissions, so you need to enter the administrator password on request.
